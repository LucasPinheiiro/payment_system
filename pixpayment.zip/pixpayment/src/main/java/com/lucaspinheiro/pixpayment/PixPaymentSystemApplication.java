package com.lucaspinheiro.pixpayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PixPaymentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PixPaymentSystemApplication.class, args);
	}

}
