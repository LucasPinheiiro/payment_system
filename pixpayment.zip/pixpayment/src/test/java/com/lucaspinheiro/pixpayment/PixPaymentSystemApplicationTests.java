package com.lucaspinheiro.pixpayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PixPaymentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
